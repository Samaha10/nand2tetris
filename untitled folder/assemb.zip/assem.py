import re
import sys

 

symbol_table= {'SP':0, 'LCL':1, 'ARG':2, 'THIS':3, 'THAT':4, 
'R0':0, 'R1':1, 'R2':2, 'R3':3, 'R4':4, 'R5':5, 'R6':6, 'R7':7, 
'R8':8, 'R9':9, 'R10':10, 'R11':11, 'R12':12, 'R13':13, 'R14':14, 'R15':15, 
'SCREEN':16384, 'KBD':24576} 

jumps = ['', "JGT", "JEQ", "JGE", "JLT", "JNE", "JLE", "JMP"]

comp_codes = {'0': '101010', '1': '111111', '-1':'111010', 
'D':'001100', 'A': '110000', '!D': '001101', 
'!A': '110001', '-D': '001111', '-A': '110011', 
'D+1': '011111', 'A+1': '110111', 
'D-1': '001110', 'A-1': '110010', 
'D+A': '000010', 'D-A': '010011', 'A-D':'000111', 
'D&A': '000000', 'D|A': '010101', } 

var_counter = 16

def a_instruct(instruct):
    x = instruct[1:]
    global symbol_table
    global var_counter
    
    # number literal case 
    if x.isdigit():
        # 15- bit digits , guarenteed 0 16th
        val = int(x)
    # label / variable
    else:
        # first time variable
        if x not in symbol_table:
            symbol_table[x] = var_counter
            var_counter += 1
        
        val = symbol_table[x]

    return '{0:016b}'.format(val) + '\n'
     

def c_instruct(instruct):
    dest_split = instruct.split('=')
    if len(dest_split) == 2:
        d = dest_split[0]
        remain = dest_split[1]
    else:
        d = ''
        remain = dest_split[0]
    destination = dest_process(d)
    

    jump_split = remain.split(';')
    j = jump_split[1] if len(jump_split) == 2 else ''
    jump = '{0:03b}'.format(jumps.index(j))
    
    
    compute = comp_process(jump_split[0])

    return ''.join(["111", compute, destination, jump, '\n'])  

def dest_process(dest):
    d1 = '1' if 'A' in dest else '0'
    d2 = '1' if 'D' in dest else '0'
    d3 = '1' if 'M' in dest else '0'
    return d1 + d2 + d3

def comp_process(comp):
    a = '1' if 'M' in comp else '0'
    code = comp_codes[comp.replace('M', 'A')]
    return a + code


def label(lab):
    return re.sub('[()]','', lab)

def main():
    global symbol_table
    if len(sys.argv) != 2:
        print("No file provided")
        return

    with open(sys.argv[1], 'r') as file:
        content = file.readlines()
    content = [re.sub('[ \n]', '', line).split('/')[0] for line in content]
    # delete white lines and comments
    content = [line for line in content if line]

    # first pass (labels)
    # A label can be defined only once
    i = 0
    for line in content:
        if line and line[0] == '(':
            symbol_table[label(line)] = i
            continue
        i += 1


    # second pass
    bin_code = []
    for line in content:
        if line and line[0] != '(':
            if line[0] == '@':
                bin_code.append(a_instruct(line))
            else:
                bin_code.append(c_instruct(line))

    fname = sys.argv[1].split('.')[0] + '.hack'

    with open(fname, 'w') as f:
        f.writelines(bin_code)


if __name__=="__main__":
    main()
